**What happened?**

Please provide as many of the following as applies:
* stacktrace of the error
* screen shots
* a dump of the error log with both moodle debugging on full and saml debugging on as well


**What you expected:**
